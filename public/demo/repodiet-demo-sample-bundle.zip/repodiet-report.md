# RepoDiet Cleanup Report

## Repository

- Owner/repo: repodiet/demo-slop-app
- Branch: main
- URL: https://github.com/repodiet/demo-slop-app
- Framework: Next.js
- Package manager: npm

## Summary

- Duplicate clusters: 7
- Unused files: 14
- Unused dependencies: 9
- Orphan patterns: 1
- AI-slop signals: 6
- Safe candidates: 5
- Raw review findings: 33
- Unique review items: 16
- Do not touch protected items: 14

## Count semantics

- **Raw review findings** — total findings flagged `review_first` before path deduplication.
- **Unique review items** — deduplicated files/packages documented for patch review.
- **Do not touch** — protected framework, config, route, and runtime paths.

## Key findings

- **duplicate_code** (review_first) `app/api/execute-plan/route.ts, app/api/execute/plan/route.ts` — Similar logic appears in multiple files.
- **duplicate_code** (review_first) `app/api/execute-plan/route.ts, app/api/old-execute/route.ts` — Similar logic appears in multiple files.
- **duplicate_code** (review_first) `components/Button.tsx, components/Button2.tsx` — Similar logic appears in multiple files.
- **duplicate_code** (review_first) `components/Button.tsx, components/ButtonCopy.tsx` — Similar logic appears in multiple files.
- **duplicate_code** (review_first) `components/Button.tsx, components/ButtonFinal.tsx` — Similar logic appears in multiple files.
- **duplicate_code** (review_first) `lib/utils-copy.ts, lib/utils-old.ts` — Similar logic appears in multiple files.
- **duplicate_code** (review_first) `lib/utils-copy.ts, lib/utils.ts` — Similar logic appears in multiple files.
- **unused_file** (safe_candidate) `archive/OldDashboard.tsx` — File is not referenced by import graph or framework entry points.
- **unused_file** (safe_candidate) `backup/GeneratedCardCopy.tsx` — File is not referenced by import graph or framework entry points.
- **unused_file** (review_first) `components/Button2.tsx` — File is not referenced by import graph or framework entry points.
- **unused_file** (review_first) `components/ButtonCopy.tsx` — File is not referenced by import graph or framework entry points.
- **unused_file** (review_first) `components/ButtonFinal.tsx` — File is not referenced by import graph or framework entry points.
- **unused_file** (review_first) `components/HeroBackup.tsx` — File is not referenced by import graph or framework entry points.
- **unused_file** (review_first) `components/HeroOld.tsx` — File is not referenced by import graph or framework entry points.
- **unused_file** (review_first) `components/UnusedCard.tsx` — File is not referenced by import graph or framework entry points.
- **unused_file** (review_first) `components/UnusedModal.tsx` — File is not referenced by import graph or framework entry points.
- **unused_file** (review_first) `hooks/useOldState.ts` — File is not referenced by import graph or framework entry points.
- **unused_file** (review_first) `lib/utils-copy.ts` — File is not referenced by import graph or framework entry points.
- **unused_file** (safe_candidate) `lib/utils-old.ts` — File is not referenced by import graph or framework entry points.
- **unused_file** (safe_candidate) `old/UnusedLandingOld.tsx` — File is not referenced by import graph or framework entry points.

## Patch policy

RepoDiet generated a conservative patch bundle.
No protected framework/runtime files were included in automatic delete operations.

## Next steps

1. Review Safe Candidates.
2. Apply cleanup patch.
3. Run regression checklist.
4. Re-run RepoDiet.
