# Package Cleanup Suggestions

## Review before removing

- `react`
  - Reason: Package is listed in package.json but no usage was found.
  - Source: knip
  - Confidence: 84%
  - After manual confirmation: `npm uninstall react`

- `react-dom`
  - Reason: Package is listed in package.json but no usage was found.
  - Source: knip
  - Confidence: 84%
  - After manual confirmation: `npm uninstall react-dom`

- `lodash`
  - Reason: Package is listed in package.json but no usage was found.
  - Source: knip
  - Confidence: 84%
  - After manual confirmation: `npm uninstall lodash`

- `moment`
  - Reason: Package is listed in package.json but no usage was found.
  - Source: knip
  - Confidence: 84%
  - After manual confirmation: `npm uninstall moment`

- `uuid`
  - Reason: Package is listed in package.json but no usage was found.
  - Source: knip
  - Confidence: 84%
  - After manual confirmation: `npm uninstall uuid`

- `chalk`
  - Reason: Package is listed in package.json but no usage was found.
  - Source: knip
  - Confidence: 84%
  - After manual confirmation: `npm uninstall chalk`

- `date-fns`
  - Reason: Package is listed in package.json but no usage was found.
  - Source: knip
  - Confidence: 84%
  - After manual confirmation: `npm uninstall date-fns`

- `axios`
  - Reason: Package is listed in package.json but no usage was found.
  - Source: knip
  - Confidence: 84%
  - After manual confirmation: `npm uninstall axios`

- `@types/react`
  - Reason: Package is listed in package.json but no usage was found.
  - Source: knip
  - Confidence: 84%
  - After manual confirmation: `npm uninstall @types/react`
