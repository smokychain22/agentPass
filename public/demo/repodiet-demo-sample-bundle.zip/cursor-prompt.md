# Cursor Cleanup Prompt

You are cleaning a JavaScript/TypeScript repo using RepoDiet findings.

## Rules
- Do not delete framework routes, layouts, API routes, config files, env files, lockfiles, or public assets without confirmation.
- Start with safe candidates only, then handle unique review items separately.
- For unique review items, inspect imports and runtime usage before changing.
- After every cleanup batch, run lint and build.
- Preserve app behavior.

## Repo
- URL: https://github.com/repodiet/demo-slop-app
- Branch: main
- Framework: Next.js
- Package manager: npm

## Findings summary
- Duplicate clusters: 7
- Unused files: 14
- Unused dependencies: 9
- Orphan patterns: 1
- AI-slop signals: 6
- Safe candidates: 5
- Raw review findings: 33
- Unique review items: 16
- Do not touch protected items: 14

## Safe candidates
- `archive/OldDashboard.tsx` — File is not referenced by import graph or framework entry points.
- `backup/GeneratedCardCopy.tsx` — File is not referenced by import graph or framework entry points.
- `lib/utils-old.ts` — File is not referenced by import graph or framework entry points.
- `old/UnusedLandingOld.tsx` — File is not referenced by import graph or framework entry points.
- `tmp/temp-widget.tsx` — File is not referenced by import graph or framework entry points.

## Unique review items
- `backup/GeneratedCardCopy.tsx` — Files with Old/New/Final/Backup/Copy suffixes suggest AI-generated iteration leftovers.
- `components/Button.tsx` — Similar logic appears in multiple files.
- `components/Button2.tsx` — Similar logic appears in multiple files.
- `components/ButtonCopy.tsx` — Similar logic appears in multiple files.
- `components/ButtonFinal.tsx` — Similar logic appears in multiple files.
- `components/Hero.tsx` — Multiple near-identical component names in one folder suggest duplicate AI iterations.
- `components/HeroBackup.tsx` — File is not referenced by import graph or framework entry points.
- `components/HeroOld.tsx` — File is not referenced by import graph or framework entry points.
- `components/UnusedCard.tsx` — File is not referenced by import graph or framework entry points.
- `components/UnusedModal.tsx` — File is not referenced by import graph or framework entry points.
- `hooks/useOldState.ts` — File is not referenced by import graph or framework entry points.
- `lib/utils-copy.ts` — Similar logic appears in multiple files.
- `lib/utils-old.ts` — Similar logic appears in multiple files.
- `lib/utils.ts` — Similar logic appears in multiple files.
- `old/UnusedLandingOld.tsx` — Files with Old/New/Final/Backup/Copy suffixes suggest AI-generated iteration leftovers.
- `page.tsx` — File is not reached from detected app entry points in the dependency graph.

## Do not touch
- `app/api/execute-plan/route.ts` — Similar logic appears in multiple files.
- `app/api/execute/plan/route.ts` — Similar logic appears in multiple files.
- `app/api/old-execute/route.ts` — Similar logic appears in multiple files.
- `archive/OldDashboard.tsx` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `backup/GeneratedCardCopy.tsx` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `components/HeroBackup.tsx` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `components/HeroOld.tsx` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `components/UnusedCard.tsx` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `components/UnusedModal.tsx` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `hooks/useOldState.ts` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `lib/utils-copy.ts` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `lib/utils-old.ts` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `old/UnusedLandingOld.tsx` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.
- `tmp/temp-widget.tsx` — TODO/FIXME/PLACEHOLDER markers often indicate unfinished AI-generated stubs.

## Task
Create a conservative cleanup PR that removes only safe files first, then proposes review changes separately.
